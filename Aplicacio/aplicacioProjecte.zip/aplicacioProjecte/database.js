module.exports = {
    'url' : 'mongodb://mongo:27017/websockets'
};